import keyboard

uSelect = ''

if keyboard.read_key() == '1':
	uSelect = ''
	while len(uSelect) <= 15 and keyboard.read_key() != 'enter':
		uSelect = uSelect + keyboard.read_key()
elif keyboard.read_key() == '2':
	print('sed')

print(uSelect)


