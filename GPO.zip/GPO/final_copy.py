import subprocess
import sys
import time
import pymongo
import datetime
import requests
import keyboard

def lcd_write(input1, input2):
	f1 = open("input.txt", "w")
	f2 = open("input2.txt", "w")
	f1.write(input1)
	f2.write(input2)
	f1.close
	f2.close

def barcode_read():
	hid = {4: 'a', 5: 'b', 6: 'c', 7: 'd', 8: 'e', 9: 'f', 10: 'g', 11: 'h', 12: 'i', 13: 'j', 14: 'k', 15: 'l', 16: 'm',
	17: 'n', 18: 'o', 19: 'p', 20: 'q', 21: 'r', 22: 's', 23: 't', 24: 'u', 25: 'v', 26: 'w', 27: 'x', 28: 'y',
	29: 'z', 30: '1', 31: '2', 32: '3', 33: '4', 34: '5', 35: '6', 36: '7', 37: '8', 38: '9', 39: '0', 44: ' ',
	45: '-', 46: '=', 47: '[', 48: ']', 49: '\\', 51: ';', 52: '\'', 53: '~', 54: ',', 55: '.', 56: '/'}

	hid2 = {4: 'A', 5: 'B', 6: 'C', 7: 'D', 8: 'E', 9: 'F', 10: 'G', 11: 'H', 12: 'I', 13: 'J', 14: 'K', 15: 'L', 16: 'M',
	17: 'N', 18: 'O', 19: 'P', 20: 'Q', 21: 'R', 22: 'S', 23: 'T', 24: 'U', 25: 'V', 26: 'W', 27: 'X', 28: 'Y',
	29: 'Z', 30: '!', 31: '@', 32: '#', 33: '$', 34: '%', 35: '^', 36: '&', 37: '*', 38: '(', 39: ')', 44: ' ',
	45: '_', 46: '+', 47: '{', 48: '}', 49: '|', 51: ':', 52: '"', 53: '~', 54: '<', 55: '>', 56: '?'}

	fp = open('/dev/hidraw0', 'rb')
	if fp:
        	fp = open('/dev/hidraw1', 'rb')

	code = ''
	shift = False
	done = False
	while not done:
		buffer = fp.read(8)
		for c in buffer:
			if ord(c) > 0:
				if int(ord(c)) == 40:
					done = True
					break
				if shift:
					if int(ord(c)) == 2:
						shift = True
					else:
						code += hid2[int(ord(c))]
						shift = False
				else:
					if int(ord(c)) == 2:
						shift = True
					else:
						code += hid[int(ord(c))]
	return code

client = pymongo.MongoClient("mongodb+srv://admin:GI1nFdtlEC2q3vxx@cluster0-rfhmi.mongodb.net/")
db = client.adas
user = {}
device = {}
uSelect = None
userAuth = False
dId = ''
dCode = ''
uId = ''
uCode = ''



while 1:
	while not userAuth:
	        lcd_write(" \x02        ", "        ")
		subprocess.call('./oLcd')
		lcd_write("  Please Press  ", "  Enter to scan  ")
	        subprocess.call('./oLcd')
		keyboard.wait('enter')
		lcd_write("      scan      ", "       QR       ") 
		subprocess.call("./oLcd")
		uCode = barcode_read()
		print (uCode)
	        try:
        		user = db["users"].find_one({ "code": uCode })
			user['code']
	        except TypeError:
        		user = {
               		 'code': None
            		}
	        if user['code'] == uCode:
			userAuth = True
			uId = str(user['_id'])
			lcd_write("So good, Hello", user['login'])
			subprocess.call('./oLcd')
        	else:
	            userAuth = False
	            lcd_write("User not found!", "Please try again")
	            subprocess.call('./oLcd')
		time.sleep(5)
	while 1:
		lcd_write("1.Take 2.Return", "  Enter go back  ")
                subprocess.call('./oLcd')
		if keyboard.read_key() == '1':
        		dCode = ''
			lcd_write("Write code or ", "  Enter to scan  ")
                        subprocess.call('./oLcd')
		        while len(dCode) <= 15 and keyboard.read_key() != 'enter':
	        		        dCode = dCode + keyboard.read_key()
			if dCode == '':
				lcd_write("      scan      ", "      QR      ")
				subprocess.call("./oLcd")
				dCode = barcode_read()
			print(dCode)
			try:
				device = db["auditories"].find_one({ "code": dCode, "taken": 0})
				device['code']
			except TypeError:
				device = { 'code': None }
			if device['code'] == dCode:
				device_upd = db["auditories"].update({"code": dCode}, {"$set" : {"taken" : uId}})
				dSearch = db["auditories"].find_one({"code": dCode})
				devId = str(dSearch["_id"])
				post = {"received": datetime.datetime.now(),
            				"user_id" : uId,
            				"device_id" : devId,
            				"returned" : 0 ,
            				"__v" : 0}
				device_log = db["logs"].insert_one(post)
				lcd_write("Device is found", "Enter for quit")
				subprocess.call('./oLcd')
				time.sleep(5)
			else:
				lcd_write("Device not found", "Please try again")
				subprocess.call('./oLcd')
				time.sleep(5)
		elif keyboard.read_key() == '2':
	        	dCode = ''
                        lcd_write("Write code or ", "  Enter to scan  ")
                        subprocess.call('./oLcd')
                        while len(dCode) <= 15 and keyboard.read_key() != 'enter':
                                        dCode = dCode + keyboard.read_key()
                        if dCode == '':
                                lcd_write("      scan      ", "      QR      ")
                                subprocess.call("./oLcd")
                                dCode = barcode_read()
                        print(dCode)
                        try:
				device = db["auditories"].find_one({ "code": dCode, "taken": uId})
				device['code']
			except TypeError:
				device = { 'code': None }
			if device['code'] == dCode:
				device_upd = db["auditories"].update({"code": dCode}, {"$set" : {"taken" : 0}}) 
                                dSearch = db["auditories"].find_one({"code": dCode})
                                devId = str(dSearch["_id"])
                                post = {"received": 0,
                                        "user_id" : uId,
                                        "device_id" : devId,
                                        "returned" : datetime.datetime.now() ,
                                        "__v" : 0}
                                device_log = db["logs"].insert_one(post)
				lcd_write("Device is found", "Enter for quit")
                                subprocess.call('./oLcd')
                                time.sleep(5)
                        else:
                                lcd_write("Device not found", "Please try again")
                                subprocess.call('./oLcd')
                                time.sleep(5)
		elif keyboard.read_key() == 'enter':
			lcd_write("    Goodbye!    ", user['login'])
                        subprocess.call('./oLcd')
			uCode = ''
			uId = ''
			devId = ''
			userAuth = False
			time.sleep(5)
			break
		time.sleep(5)
