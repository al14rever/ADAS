import keyboard 

code = '46346346345634'
keyboard.write(code, delay=0.05)
c = input()
print(code)
