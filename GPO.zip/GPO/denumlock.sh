#!/bin/sh

sleep "$1"
numlockx on
