#!/bin/sh
/root/main.sh
