
import requests
payload = {'key': 0002, 'auditory': 404, 'user': 4564, 'device': 456}
r = requests.post("http://212.192.114.20:2280/post.php", data=payload)
print(r.text)
