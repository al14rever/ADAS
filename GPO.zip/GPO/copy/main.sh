#!/bin/sh
python final.py
