#!/bin/bash

python /root/final_copy.py
