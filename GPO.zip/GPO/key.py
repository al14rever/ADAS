import keyboard


def print_pressed_keys(e):
    try:
        print(e, e.event_type, e.name)
    except UnicodeEncodeError:
        print 'shit'
    except IOExit:
	print 'shit'
keyboard.hook(print_pressed_keys)
keyboard.wait()
